from django.contrib import admin
from api.models import Producct,Category
admin.site.register((Producct, Category))
# Register your models here.
